import requests

url = 'http://192.168.1.20:5000/set_data'

myobj = {'steering_wheel': [{'num': 4}]}

x = requests.post(url, json = myobj)
