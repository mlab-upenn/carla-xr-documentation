from urllib import request
from flask import Flask
from flask import jsonify

app = Flask(__name__)

test_json = {'steering_wheel': [{"data": "test_string"}]}
           

@app.route("/steering_data")
def steering_data():
    return jsonify(test_json)

@app.route("/set_steer")
def set_steer():
    test_json["steering_wheel"]["data"] = request.args.post("json")
    return 0

if __name__ == "__main__":
    app.run("0.0.0.0", debug=True)