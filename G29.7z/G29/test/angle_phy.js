//----------
// Includes
//----------
const color = require('../code/color.js')
const g     = require('../code/index.js')

var express = require('express');
var bodyParser = require('body-parser');

var app = express();
  
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const wheelOptions = {
    autocenter: false,
    debug: false,
    range: 900
}

//----------------------------------
// Distract the humans for a moment
//----------------------------------
console.log(color.cyan('Setting up wheel.'))
console.log(color.cyan('One moment please.'))
console.log(color.gray('If nothing happens, try moving the wheel.'))

//-----------------------------------
// Connect to Wheel and Setup Events
//-----------------------------------

g.connect(wheelOptions, function(err) {
    g.forceConstant(0.5)
    g.forceFriction(0.45)

    console.log(color.cyan('Wheel ready.'))

    app.listen(3000);

    app.post("/arraysum", (req, res) => {
        // Retrieve array form post body
        var array = req.body.array;  
        res.json("input received");

        if(array[0] == -1 && array[1] == -1){
            g.forceConstant(0.5)
            g.forceFriction(0.45)
            // turn off auto centerling
            g.relayOS([0xf5, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
            console.log("Manual Mode Activated");
        }
        else{
            g.forceConstant(array[0])
            g.forceFriction(array[1])   
            // turn on auto centerling
            g.relayOS([0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
        }
    });
})