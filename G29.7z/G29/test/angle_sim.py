from flask import Flask
from flask import request
from flask import jsonify

app = Flask(__name__)

class DataStorage:
    steer = {'steering_wheel': [{"data": '-1'}], 'autopilot_status': [{"data": '0'}], 'sound': [{"data": '0'}], 'velocity': [{"data": '0'}]}

storage = DataStorage()
           
@app.route("/get_steer")
def steering_data():
    print(storage.steer)
    return jsonify(storage.steer)

@app.route("/set_steer", methods=['PUT', 'POST'])
def set_data():
    storage.steer = request.get_json()
    print(storage.steer)
    return jsonify(True)

if __name__ == "__main__":
    app.run("0.0.0.0", port = 5000, debug=True)